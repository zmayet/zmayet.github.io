package game;

import city.cs.engine.*;
import city.cs.engine.Shape;
import org.jbox2d.common.Vec2;

import static java.awt.Color.black;

import javax.swing.*;

import java.awt.*;

public class GameWorld extends World {

    private Student student;



    public GameWorld(){
        Container con;
        JPanel titleNamePanel;
        JLabel titleNameLabel;
        titleNamePanel = new JPanel();
        titleNamePanel.setBounds(100,100,100,100);
        titleNamePanel.setBackground(Color.black);
        titleNameLabel = new JLabel("My Game");
        titleNameLabel.setForeground(Color.white);
        titleNamePanel.add(titleNameLabel);
        //con.add(titleNamePanel);



        // make the ground
        Shape shape = new BoxShape(11, 0.5f);
        StaticBody ground = new StaticBody(this, shape);
        ground.setPosition(new Vec2(6, 7.5f));
        ground.setFillColor(black);


        // make a platform
        Shape platform1Shape = new BoxShape(11, 0.5f);
        StaticBody platform1 = new StaticBody(this, platform1Shape);
        platform1.setPosition(new Vec2(-6, -1f));
        platform1.setFillColor(black);

        // add another platform here
        Shape platform2Shape = new BoxShape(11, 0.5f);
        StaticBody platform2 = new StaticBody(this, platform2Shape);
        platform2.setPosition(new Vec2(4, -11.5f));
        platform2.setFillColor(black);

        for(int i = 0; i < 4; ++i){
        Coin coin = new Coin(this);
        coin.setPosition(new Vec2(5f+i*2,-8));}

       for(int i = 0; i < 4; ++i){
         Coin coin = new Coin(this);
            coin.setPosition(new Vec2(-13f+i*2,3));}

        for(int i = 0; i < 4; ++i){
            Coin coin = new Coin(this);
            coin.setPosition(new Vec2(1f+i*2,11));}

       student = new Student(this);
       student.setPosition(new Vec2(14, -10));

       //BooksPickup pickup = new BooksPickup(student);
      // student.addCollisionListener(pickup);
        StudentCollision pickup = new StudentCollision();
        student.addCollisionListener(pickup);



        // add more bodies here
        Professor professor = new Professor(this);
        professor.setPosition(new Vec2(-4,1));





    }


    public Student getStudent(){
        return student;
    }
}
