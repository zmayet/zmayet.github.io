package game;

import city.cs.engine.CollisionEvent;
import city.cs.engine.CollisionListener;
import org.jbox2d.common.Vec2;

//public class DragonCollision implements CollisionListener {
  //  private Student student;
    //public DragonCollision(Student s) {
   //     this.student = s;
    //}

    public class DragonCollision implements CollisionListener {
        private Professor professor;
        private Books books;

        public DragonCollision(Books b) {
            this.books = b;
        }



    @Override
    public void collide(CollisionEvent e) {
        if (e.getOtherBody() instanceof Professor) {
            e.getOtherBody().destroy();
            e.getReportingBody().destroy();

        }

    }
}