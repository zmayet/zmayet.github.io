package game;
import city.cs.engine.*;
public class Student extends Walker {
    private static final Shape studentShape = new PolygonShape(
            -0.38f,2.15f, 0.57f,0.99f, 0.75f,-0.94f, 0.53f,-2.29f, -0.52f,-1.87f, -1.32f,0.28f);

    private static final BodyImage image =
            new BodyImage("data/student.png", 5f);

    private int CoinCount;
    public int NoOfLives;

    public Student(World world) {
        super(world, studentShape);
        addImage(image);
        CoinCount = 0;
        NoOfLives = 3;

    }

    public void addCoin(){
        CoinCount++;
        System.out.println("Coin Count = " + CoinCount);
    }




    public int getNoOfLives(){
        return NoOfLives;
    }

    public void decrementNoOfLives(){
        NoOfLives--;
        System.out.println("Number of lives left = " + NoOfLives);
    }
}