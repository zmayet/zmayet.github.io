package game;

import city.cs.engine.*;

public class Professor extends Walker {

    private static final Shape professorShape = new PolygonShape(
            0.98f,1.59f, 1.43f,-0.01f, 1.4f,-1.84f, -1.03f,-1.41f, -1.62f,0.81f, -0.39f,1.81f);

    private static final BodyImage image =
            new BodyImage("data/professor.png", 6f);


    public Professor(World world) {
        super(world, professorShape);
        addImage(image);
    }
}
