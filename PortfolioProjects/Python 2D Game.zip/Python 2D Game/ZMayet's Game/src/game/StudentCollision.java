
package game;

import city.cs.engine.CollisionEvent;
import city.cs.engine.CollisionListener;
import org.jbox2d.common.Vec2;

public class StudentCollision implements CollisionListener {

    public void collide(CollisionEvent e) {
        Student reportingStudent = (Student) e.getReportingBody();
        if (e.getOtherBody() instanceof Coin) {
            reportingStudent.addCoin();
            e.getOtherBody().destroy();

        } else if(e.getOtherBody() instanceof Professor){
            //System.out.println("bam!");
            reportingStudent.decrementNoOfLives();

            // e.getOtherBody().destroy();
        }

        if(reportingStudent.NoOfLives == 0){
            reportingStudent.setPosition(new Vec2(14, -10));
        }
    }
}









