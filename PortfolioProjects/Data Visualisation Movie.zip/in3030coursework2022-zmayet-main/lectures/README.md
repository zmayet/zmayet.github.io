---
id: litvis
---

@import "../lectures/css/datavis.less"

![Data visualization](../images/banner.jpg)

# IN3030 Lecture Content

This is the place where you can put the weekly lecture materials downloaded from Moodle. Having your own copy of each week's lecture materials allows you to add your personal annotations and other content as you progress through the module.

There is a separate folder for each week's content. The first week's material is already provided, so no need to download that from Moodle.
