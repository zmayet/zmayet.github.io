---
id: litvis

narrative-schemas:
  - ../../lectures/narrative-schemas/teaching.yml

elm:
  dependencies:
    gicentre/elm-vegalite: latest
    gicentre/tidy: latest
---

@import "../../lectures/css/datavis.less"

```elm {l=hidden}
import Tidy exposing (..)
import VegaLite exposing (..)
```

<!-- Everything above this line should probably be left untouched. -->

# Session 1: Practical Exercises

{(task|}

Use this document as a place to add your answers to the week's practical exercises.

{|task)}

## Q.3 Datavis Evaluation

_Add your 5-point critique here (see Q.3 of the session 1 practical exercises)._

## Q.4 Bicycle Hires Visualization

```elm {l highlight=[1,2,3,4,5,6,7,8,9,10,11,12]}
myBarchart : Spec
myBarchart =
    let
        data =
            dataFromUrl "https://gicentre.github.io/data/bicycleHiresLondon.csv"

        enc =
            encoding
                << position X [ pName "Month", pTemporal ]
                << position Y [ pName "NumberOfHires", pQuant ]
    in
    toVegaLite [ width 640, data [], enc [], bar [] ]
```

^^^elm v=myBarchart^^^

## Q.5 Creating a Scatterplot

```elm {l highlight=[1,2,3,4,5,6,7,8,9,10,11,12]}
scatterplot : Spec
scatterplot =
    let
        data =
            dataFromUrl "https://gicentre.github.io/data/bicycleHiresLondon.csv"

        enc =
            encoding
                << position X [ pName "Month", pTemporal ]
                << position Y [ pName "NumberOfHires", pQuant ]
    in
    toVegaLite [ width 640, data [], enc [], point [] ]
```

^^^elm v=scatterplot^^^

## Q.6 Data Challenge

```elm{ l v}
scatter : Spec
scatter =
    let
        data =
            dataFromUrl "https://gicentre.github.io/data/euPolls.json"

        enc =
            encoding
                << position X [ pName "Date", pTemporal ]
                << position Y [ pName "Percent", pQuant ]
                << color [ mName "Answer", mNominal ]
    in
    toVegaLite [ width 440, data [], enc [], circle [] ]
```

The data above represents the percatege of people and their votes during the brexit voting. Blue showing the number of people who voted to remain, orange with the percentage of people who didnt vote or dont have an answer and red showing the the percentage of peole wanting to leave.

## Q.7 Design Challenge

_Add a link to a photo of your design sketch._
