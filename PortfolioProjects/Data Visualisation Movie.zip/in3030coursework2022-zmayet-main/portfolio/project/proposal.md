---
id: litvis

narrative-schemas:
  - ../../lectures/narrative-schemas/proposal.yml
---

@import "../../lectures/css/datavis.less"

# Project Proposal

{(whoami|} Zainab Mayet: zainab.mayet@city.ac.uk {|whoami)}

{(task|}

You should complete this datavis project proposal by **Sunday 6th November, 5pm UK time** ensuring you have committed and pushed it to GitHub. Successful submissions by that time will be awarded up to **5 marks** towards your coursework assessment total.

{|task)}

{(questions|}

Is the movie industry dying?

- What is the correlation between gross and production company // justify
- Which of the four seasons produce the highest average gross revenue for movies? and has that changed over time? // bad
- Have the number of viewers decreased over the years? Why may that be? // good
- Is there direct correlation between movie quality and its gross revenue? // justify 
- How ,if at all, does the cost of producing a movie impact its ratings? // justify
- Is it harder for a movie to achieve a high rating (above 8) the more votes it has? // bad

{|questions)}

{(datasources|}

_A brief sentence or two with links to data sources._ https://www.kaggle.com/datasets/danielgrijalvas/movies
In regards to this module I decided to go with a dataset about movies. For years now, there has been a stipulation that the movie industry is dying. However, whenever a blockbuster movie was released i would still struggle to find tickets and when I would finally go the room would be full to the brim. So, with this coursework i wanted to answer the question once and for all. This dataset is not only compiled by a reliable source, it has copius amounts of data on the movie industry over the last few decades. Giving me what I need to come to my own conclusion, and visualise the data to help others come to their own.

{|datasources)}

{(justification|}

_A couple of sentences on why you need datavis to answer your research questions._
Data Visualisation’s main goal is to use existing data and make it so there is room for new findings to be discovered i.e., patterns or trends outlined in large datasets. This statement ties in with my chosen research questions as with the data in its raw format being able to identify specific trends would prove to be quite difficult if not impossible with the vast amount of data. Thus, using data visualisation these new findings / patterns would be extremely visible, for example the correlation between gross and production company. Whereas if an individual was given a series of totals and tables, to compare and use to identify the same trend could potentially result in a very limited analysis with a lack of useful discoveries.
However, if that data was to be produced in a visually appealing format i.e., scatter diagram, the viewer could quite quickly notice either a positive or negative correlation between the two. This is efficient as a great deal of time would be saved. Without this data being converted using data visualisation an individual could potentially spend several weeks analysing the numbers and trying to establish a connection between the two. Additionally, if the data has a small range this would further increase the time it takes to establish a trend using tables and totals. This time instead could be used to tackle other issues or queries, i.e., why is there a substantial difference between the two factors.

{|justification)}
