## Proposal mark: 3 out of 5

There's certainly a lot to look at in movie databases. Your RQs are generally fine but I wasn't sure how well they helped answer your overall one on whether the movie industry is declining (which is a good Q to investigate). Think about which aspects of the data will help you explore that main RQ.

Your research questions are thematically relevant and provide some pointers that may help you in your visualization design at the implementation phase. There is scope to align them more strongly with the visualization process, perhaps by making them more specific or in a way that isolates the aspect of understanding you are aiming to support. In that way they should help you to make design decisions when you get to the visualization design and implementation stages.

You provide some justification for visualizing your data, but it could benefit from a greater focus on why data visualization specifically is an effective approach to take. That focus should help you to think further about why visualization is relevant to the investigation of your RQs and so should help you with your design process when conducting the main coursework exercise.