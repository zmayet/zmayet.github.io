---
id: litvis

narrative-schemas:
  - ../../lectures/narrative-schemas/project.yml

elm:
  dependencies:
    gicentre/elm-vegalite: latest
    gicentre/tidy: latest
---

@import "../../lectures/css/datavis.less"

```elm {l=hidden}
import Tidy exposing (..)
import VegaLite exposing (..)
```

# Data Visualization Project Summary

{(whoami|} Zainab Mayet - zainab.mater@city.ac.uk {|whoami)}

{(task|}

You should complete this datavis project summary document and submit it, along with any necessary supplementary files to **Moodle** by **Sunday 18th December, 5pm UK time**. Submissions will be awarded up to **80 marks** towards your coursework assessment total.

You are also encouraged to regularly commit and push changes to your datavis project throughout the term as you develop your project.

{|task)}

{(questions|}

- What genre was the most popular over the last 50 years?
- Is there direct correlation between IMDB score and gross?
- What is the correlation between year and votes?
- Does the runtime compared to votes and year have any correlation?
- How ,if at all, does the budget impact its IMBD score?
- Which countries produced the most movies between the 80s and 2010s?
- How can the relationship between budget and gross be described?

{|questions)}

{(visualization|}

```elm {l=hidden}
cyclehireData : Data
cyclehireData =
    dataFromUrl "https://raw.githubusercontent.com/zmayet/datasets/main/moviesmod.csv" []
```

```elm {l=hidden}
vegaPath : String
vegaPath =
    "https://raw.githubusercontent.com/zmayet/datasets/main/moviesmod.csv"

vegaPath1 : String
vegaPath1 =
    "https://raw.githubusercontent.com/zmayet/datasets/main/q7.csv"

giCentrePath : String
giCentrePath =
    "https://gicentre.github.io/data/"
```

Q1) What genre was the most popular over the last 50 years?

```elm {v}
year : Spec
year =
    let
        cfg =
            configure
                << configuration (coView [ vicoStroke Nothing ])
                << configuration (coAxis [ axcoTicks True, axcoDomain True, axcoLabelAngle -100 ])
                << configuration (coBackground "#FFF6FD")


        data =
            dataFromUrl "https://raw.githubusercontent.com/zmayet/datasets/main/moviesmod.csv"
                -- Force session values to be treated as numbers not text
                [ parse [ ( "score", foNum ) ] ]

        enc =
            encoding
                << position X [ pName "year", pTitle "Year", pAxis [ axLabelAngle 40, axLabelPadding 0 ] ]
                << position Y
                    [ pName "score"
                    , pQuant
                    , pStack stCenter -- Stacked from the centre not bottom.
                    , pAxis []

                    ]
                << detail [ dName "id" ]
                << color [ mName "genre", mTitle "Genre", mLegend [lePadding 20, leStrokeColor "black"] ]
    in
    toVegaLite
        [ title "Popular Genres Of Movies Streamgraph" [],  width 800
        , height 300
        , cfg []
        , data
        , enc []
        , area
            [ maLine (lmMarker []) -- Add lines around each area 'stream'
            , maInterpolate miMonotone -- Monotone interpolation gives curved lines
            ]
        ]
```

Q2) Is there direct correlation between IMDB score and gross?

```elm {v}
logBubble : Spec
logBubble =
    let
        data =
            dataFromUrl "https://raw.githubusercontent.com/zmayet/datasets/main/moviesmod.csv"
        cfg = 
            configure
                 << configuration (coBackground "#FFF6FD")
        enc =
            encoding
                << position X
                    [ pName "year", pTitle "Year", pScale [ scZero False  ], pAxis [ axGrid False ],pAxis [ axLabelAngle 30 ] ]
                << position Y
                    [ pName "score", pTitle "Score", pQuant, pScale [ scZero False ], pAxis [ axGrid False ] ]
                << size
                    [ mName "gross", mTitle "Gross"
                    , mScale
                        [ scRange (raNums [ 0, 700 ])
                        , scType scPow -- Area proportional to datum raised to power of some exponent
                        , scExponent 1 -- Default value (i.e. area directly proportional to datum)
                        ], mLegend [lePadding 20, leStrokeColor "black"]
                    ]
                << color [mName "score", mTitle "Score", mScale [scScheme "reds"[], scReverse False], mBin [biExtent 3 10], mLegend [lePadding 20, leStrokeColor "black"]]
 
    in
    toVegaLite [title "Correlation Between Gross & Score Bubble Chart" [], width 800, height 350, data [], enc [], cfg [],circle [] ]
```

Q3) What is the correlation between year and votes?

```elm {v}
barsByAge : Spec
barsByAge =
    let
        data =
            dataFromUrl "https://raw.githubusercontent.com/zmayet/datasets/main/moviesmod.csv"
        cfg = 
            configure
                 << configuration (coBackground "#FFF6FD")
        enc =
            encoding
                << position X [ pName "year", pTitle "Year", pOrdinal, pBin [ biStep 5 ],pAxis [ axLabelAngle 0 ] ]
                << position Y [ pAggregate opCount, pTitle "Votes"]
                << color [ mName "gender", mTitle "Gender", mScale [scScheme "redblue" [] ], mLegend [lePadding 20, leStrokeColor "black"]]
    in
    toVegaLite [ title "Correlation Between Year & Votes Bar Graph" [], width 600, data [], enc [], bar [], cfg [] ]
```

Q4) Does the runtime compared to votes and year have any correlation?

```elm {v interactive}
cycleHiresFilter : Spec
cycleHiresFilter =
    let

        cfg = 
            configure
                 << configuration (coBackground "#FFF6FD")
        data =
            dataFromUrl (vegaPath ++ "cars.json")[]

        ps =
            params
                << param "myBrush" [ paSelect seInterval [] ]

        trans =
            transform
                << filter (fiSelection "myBrush")

        enc =
            encoding
                << position X
                    [ pName "runtime", pTitle "Runtime"
                    , pQuant
                    , pScale [ scDomain (doNums [ 0, 300 ]) ]
                    ]
                << position Y
                    [ pName "votes", pTitle "Votes"
                    , pQuant
                    , pScale [ scZero False ]
                    ]
                << color [ mName "year", mScale [scScheme "teals" [] ]]

                << tooltip [ tName                     "year" ]

                << color [mName "year", mTitle "Year", mScale [scScheme "teals"[], scReverse False], mBin [biExtent 1980 2020], mLegend [lePadding 20, leStrokeColor "black"]]
    in
    toVegaLite [ title "Correlation Between Runtime & Votes Scatter Graph" [], width 450, height 400, cyclehireData, ps [], trans [], enc [], cfg [], point [] ]
```

Q5) How ,if at all, does the budget impact its IMBD score?


```elm {v}
groupedBar : Spec
groupedBar =
    let
        data =
            dataFromUrl "https://raw.githubusercontent.com/zmayet/datasets/main/moviesmod.csv"

        trans =
            transform
                << filter (fiExpr "datum.year == 2000")

        cfg = 
            configure
                 << configuration (coBackground "#FFF6FD")

        enc =
            encoding
                << position X [ pName "score", pTitle "Score", pQuant, pAxis [ axLabelAngle 0 ]]
                << position XOffset [ pName "gender" ]
                << position Y [ pName "budget", pAggregate opSum, pTitle "Budget" ]
                << color [ mName "gender", mTitle "Gender", mScale [scScheme "purplegreen" [] ], mLegend [lePadding 20, leStrokeColor "black"]]
    in
    toVegaLite [title "Correlation Between Budget & Score Bar Graph" [],width 1000, height 300, widthStep 12, data[], trans [], enc [], bar [], cfg [] ]
```

```elm {l=hidden}
carOwnershipTable : Table
carOwnershipTable =
    """countries1, NumberOfMovies80s
country,votes
United Kingdom,927
United States,65000
South Africa,52
Canada,51
West Germany,22
Australia,38
Italy,21
Australia,13
France,12
South Korea,6
Sweden,590
Mexico,60
New Zealand,21
Japan,1570
Hong Kong,150
Soviet Union,41
Ireland,1
Brazil,370
"""
        |> fromCSV
```

```elm {l=hidden}
carOwnershipTable1 : Table
carOwnershipTable1 =
    """countries1, NumberOfMoviespresent
country,votes
United Kingdom,9270000
United States,6500000
South Africa,540000
Canada,510000
West Germany,220000
Australia,380000
Italy,210000
Australia,13000
France,120000
South Korea,6590
Sweden,590000
Mexico,60000
New Zealand,21000
Japan,1570000
Hong Kong,150000
Soviet Union,41000
Ireland,1220
Brazil,370000
"""
        |> fromCSV
```

Q6) Which countries produced the most movies between the 80s and 2010s?

```elm { v interactive highlight=[13-14,19-21,37]}
londonCircles : Spec
londonCircles =
    let
        geoData =
            dataFromUrl "https://gicentre.github.io/data/geoTutorials/world-110m.json"
                [ topojsonFeature "countries1" ]
        proj =
            projection [ prType equirectangular, prRotate -156 0 0 ]

        carData =
            dataFromColumns []
                << dataColumn "countries1" (strColumn "countries1" carOwnershipTable |> strs)
                << dataColumn "NumberOfMovies80s" (numColumn "NumberOfMovies80s" carOwnershipTable |> nums)


        centroidData =
            dataFromUrl "https://raw.githubusercontent.com/zmayet/datasets/main/countries.csv"

        backgroundSpec =
            asSpec [ geoData, geoshape [ maFill "#ddd", maStroke "white" ] ]

        trans =
            transform
                << lookup "Country" (carData []) "countries1" (luFields [ "NumberOfMovies80s" ])

        enc =
            encoding
                << position Longitude [ pName "cx" ]
                << position Latitude [ pName "cy" ]
                << size
                    [ mName "NumberOfMovies80s"
                    , mScale [ scRange (raNums [ 0, 1000 ]), scType scPow, scExponent (0.2 / 0.86) ],mLegend [lePadding 20, leStrokeColor "black"]
                    ]
                << tooltips
                    [ [ tName "Country" ]
                    , [ tName "NumberOfMovies80s" ]
                    ]


        circleSpec =
            asSpec [ centroidData [], trans [], enc [], circle [ maOpacity 0.5 ] ]

        cfg =
            configure
                << configuration (coView [ vicoStroke Nothing ])
                << configuration (coLegend [ lecoOrient loBottomRight, lecoOffset -150 ])
                << configuration (coBackground "#FFF6FD")

    in
    toVegaLite
        [ title "Movies In The 80s" [], width 640, height 480, cfg [], layer [ backgroundSpec, circleSpec ], geoData
        , proj
        , geoshape [ maFill "lightgrey" ] ]
```

```elm { v interactive highlight=[13-14,19-21,37]}
londonCircles1 : Spec
londonCircles1 =
    let
        geoData =
            dataFromUrl "https://gicentre.github.io/data/geoTutorials/world-110m.json"
                [ topojsonFeature "countries1" ]
        proj =
            projection [ prType equirectangular, prRotate -156 0 0 ]

        carData =
            dataFromColumns []
                << dataColumn "countries1" (strColumn "countries1" carOwnershipTable1 |> strs)
                << dataColumn "NumberOfMoviespresent" (numColumn "NumberOfMoviespresent" carOwnershipTable1 |> nums)


        centroidData =
            dataFromUrl "https://raw.githubusercontent.com/zmayet/datasets/main/countries.csv"

        backgroundSpec =
            asSpec [ geoData, geoshape [ maFill "#ddd", maStroke "white" ] ]

        trans =
            transform
                << lookup "Country" (carData []) "countries1" (luFields [ "NumberOfMoviespresent" ])

        enc =
            encoding
                << position Longitude [ pName "cx" ]
                << position Latitude [ pName "cy" ]
                << size
                    [ mName "NumberOfMoviespresent"
                    , mScale [ scRange (raNums [ 0, 1000 ]), scType scPow, scExponent (0.2 / 0.86) ],mLegend [lePadding 20, leStrokeColor "black"]
                    ]
                << tooltips
                    [ [ tName "Country" ]
                    , [ tName "NumberOfMovies1" ]
                    ]

        circleSpec =
            asSpec [ centroidData [], trans [], enc [], circle [ maOpacity 0.5 ] ]

        cfg =
            configure
                << configuration (coView [ vicoStroke Nothing ])
                << configuration (coLegend [ lecoOrient loBottomRight, lecoOffset -150 ])
                 << configuration (coBackground "#FFF6FD")

    in
    toVegaLite
        [ title "Movies In Present Day" [], width 640, height 480, cfg [], layer [ backgroundSpec, circleSpec ], geoData
        , proj
        , geoshape [ maFill "lightgrey" ] ]
```

Q7) How can the relationship between budget and gross be described?

```elm {v interactive}
dynamicRescaling : Spec
dynamicRescaling =
    let
        data =
            dataFromUrl (vegaPath1) [ parse [ ( "date", foDate "" ) ] ]

        ps =
            params
                << param "index"
                    [ paSelect sePoint [ seToggle tpFalse, seOn "mouseover", seEncodings [ chX ], seNearest True ]
                    , paValues (dataObjects [ [ ( "x", dt [ dtYear 2005, dtMonthNum Jan, dtDate 1 ] ) ] ])
                    ]

        trans =
            transform
                << lookupSelection "symbol" "index" "symbol"
                << calculateAs "datum.index && datum.index.price > 0 ? (datum.price - datum.index.price)/datum.index.price : 0"
                    "indexed_price"

        pointEnc =
            encoding
                << position X [ pName "date", pTemporal, pAxis [] ]

        pointSpec =
            asSpec [ ps [], pointEnc [], point [ maOpacity 0 ] ]

        lineEnc =
            encoding
                << position X [ pName "date", pTemporal, pAxis [] ]
                << position Y [ pName "indexed_price", pTitle "Price", pQuant]
                << color [ mName "symbol", mTitle "Gross & Budget",                 mLegend [lePadding 20, leStrokeColor "black"] ]

        lineSpec =
            asSpec [ trans [], lineEnc [], bar [] ]

        ruleTrans =
            transform
                << filter (fiSelection "index")

        ruleEnc =
            encoding
                << position X [ pName "date", pTemporal, pAxis [] ]
                << color [ mStr "firebrick" ]
                << color [                mLegend [lePadding 20, leStrokeColor "black"]]
        cfg =
            configure

                 << configuration (coBackground "#FFF6FD")

        textEnc =
            encoding
                << position Y [ pNum 310 ]
                << text [ tName "date", tTimeUnit yearMonth ]

        labelledRuleSpec =
            asSpec
                [ ruleTrans []
                , ruleEnc []
                , layer
                    [ asSpec [ rule [ maStrokeWidth 0.5 ] ]
                    , asSpec [ textEnc [], textMark [ maAlign haCenter, maFontWeight (fwValue 100) ] ]
                    ]
                ]
    in
    toVegaLite [title "Correlation Between Budget & Gross Bar Graph" [], width 540, height 300, data, layer [ pointSpec, lineSpec, labelledRuleSpec ], cfg[]]
```

{|visualization)}

Throughout this assignment I will attempt to tackle the question “Is the movie industry dying”. Over the years there has been many advancements regarding science, technology, entertainment etc. Specifically looking at the entertainment industry, individuals today compared to individuals in the 60s to 80s will look upon different methods in entertaining themselves. Whilst someone today would scroll through instagram or watch youtube videos, people in the late 1900s perhaps would read a book or listen to the radio. This implies that the newer generation have a shorter attention span. Even-though a similarity between the two periods such as watching shows/movies on television has remained the same, how people watch these shows/movies has differed. Meaning people would now prefer to watch things on a streaming platform such as Netflix as it provides flexibility on what they can watch and where they would perhaps want to stop their show to resume later. The concept of sitting down at home to watch a particular show/movie ceases to exists as now, individuals have the freedom to watch whatever they want to watch, wherever they want to watch it and have complete control on what time they would want to watch. As of recent times channels such as CBBC have announced the closure of their channel as “our audience move more towards digital platforms”. Through the use of my chosen dataset and visualisation I will attempt to tackle whether the movie industry is coming to an end or whether there is still hope, using the sub questions from my plan which will help me better analyse and come up with a clear conclusion. 

The dataset I will use is the “movie” dataset founded on kaggle. The dataset includes an extremely big sample of longitude data including IMDB ratings, budget, gross etc. Few amendments were made to this dataset. Firstly, I worked through the dataset to acknowledge any missing information thus deleting the entire record to receive better results during implementation. I also removed the “star” column which consisted of the main lead within the film as I believed there would be a lack of insights I could attain from this column, additionally removing unnecessary columns to simplify the dataset

{(insights|}

1.  Insight one
2.  Insight two
3.  Insight three

From 1995 to 2005 were the most predominant years within the movie industry as it produced the most movies.
This can be clearly shown in both graphs 1 (streamgraph) and graph 3 (bargraph). Firstly by looking at graph 1, it consists of the most popular genres of films developed. We can see from the mid 90s there was a massive influx of movies being developed, i.e, the colours representing the genre were much thicker in comparison to the 80s. Although there was a slight drop from 2006 it was picked up shortly after and remained constant. To sum up these findings there was a drastic increase of movies produced from the early 80s to present. Secondly, graph 3 displays the number of votes being made every five years. Similarly to graph 1 there was a massive increase in votes from the mid 90s. Although the number of votes had decreased, it had not yet reached its lowest point which were the mid 80s to early 90s. The increase of votes and movies being developed could be due to several reasons such as vast improvements within the movie industry which essentially attracted more individuals to watch movies. Regardless of the reason I can conclude from this insight that the industry may not be dying as the number of voters and movies being made has increased drastically.

Movies do better when the budget is increased.
Graph 5 displays a line graph and through the use of superposition I had displayed the budget and score onto one graph. Through the score we can assume how well or poorly a movie does as more and more people would rate a movie to be higher if they enjoy it which would ultimately increase a movie’s success. Through this graph we can analyse that not only was the budget increased over the years but the score in which they started receiving had also increased. We can assume that is due to the larger funding directors have in creating a film therefore utilising all means necessary in creating the film making it the best it can be. This can ultimately encourage more individuals to watch films. Similarly if we take a look at graph 7, we are shown the comparison between the budget and gross. The gross is exceptionally bigger in comparison to the budget. This tells us the bigger the budget the larger the gross of a film. For movie makers this data alone gives them reason to pump more and more money into movies as data has shown the more money that goes towards making a movie the more income they’ll receive after production. This also provides additionally reasoning as to why more movies are being made over the year. From this insight I can conclude that the movie industry is not dying as not only more movies but more money are being made over the years.

Movies have financially done better over the years.
Graph 2 displays a bubble chart showing how a movie's IMDB rating affects the the gross of the movie. Essentially the darker and bigger the circle the better the movie. From this chart the right hand side is concentrated with larger circles that are more pigmented as opposed to the right side of the chart where circles are very small and the colour isn't very saturated. This implies that in more recent years movies have improved in both score and financially. Secondly graph 6 displays two maps comparing the number of movies that were developed in the 80s compared to the number of movies developed in the early 2000s. The first map shows us that USA was the country that produced the most films in comparison to other countries such as UK, Canada, Japan etc. However from the second map we can see an influx of much more movies that were developed including the increase from other countries. We can physically see the circles on each country drastically enhanced as well now look a similar size to USA. Not only does these maps give me reason to believe that the movie industry is not dying but also see the mass improvements in the movie industry is other countries aside from the US.

{|insights)}

{(designJustification|}

1.  Choice one
2.  Choice two
3.  Choice three

Colour:
In graph 1 my design choice was to make use of high saturated colours. As someone who struggles to differentiate colours, I wanted to take on board this technique to make my streamgraph interpretable for individuals like myself. In session 2 a statistic was mentioned "approximately 1 in 12 men of northern European descent have a red-green colour vision deficiency making it hard to distinguish between many shades of green from shade of red".
This statement only emphasised my will to ensure that the viewer who is analysing my graph can at least establish the different sections let alone identify the different colours. In addition graph 1 consists of a variety of different genres therefore I wanted to ensure that the colours were easily differentiable thus my reasoning for using contrasting colours. This way the user will clearly be able to see what colour is representing what genre which would allow them to make a clear analysis of the graph.
In graph 5 the colours used were red and blue as many articles such as 'Ivan Kilin's' article on "The best charts for color blind viewers" go into detail how blue and red are the best colours to view when catering to people who are colourblind. Once again I wanted my viualisation to be inclusive and comprehensible to all individuals.Thus using these colours show the clear trend and relationship between both axis.
In graph 2, through using the colour red I believed I was able to enhance my main question of the movie industry dying in particular "dying" as the data looks similar to dripping blood which is commonly associated with death. I thought by having the colour change in pigmentation based on what year it is representing would be a fun, clear way to interpret the data. In David McCandless's article of 'Information is Beautiful' he mentions how data is drastically easily interpretable when it looks appealing to the eye.

Visual Variables:
In graph 2 the design technique I used was visual variables. The reason I decided to use circles was so the viewer could clearly observe whether a circle was bigger or smaller in comparison to other circles, as opposed to using another shape such as a cross where it may not be very clear to notice which one is bigger when put side by side with another variable. This factor for my graph was important as the size of the circle was being represented by the gross - an important factor to this question, thus ensuring the viewer can clearly see whether a rating improved a movie's gross was vital. In order to help me come up with this conclusion of using circles I studied Cleveland's three perceptual points when incorporating visual variables. One of his points were "estimation - the process of making comparisons of the magnitudes of data items from the visual elements used." This statements quite simply sums up my thought process when when using visual variables. Its one thing having the visualisation look visually appealing but if the viewer was to struggle to comprehend the data it defeats the purpose of it, therefore to avoid this i decided to use a common shape such as a circle so the viewer would be familiar with its shape and how it can look when expanded or shrunk. Another point from Cleveland's perceptual points which I incorporated within my visualisation was "continuity". This idea suggests that viewers are able to interpret patterns better when the data is "smooth and continuous". This is demonstrated in my visualisation as the data is presented horizontally, allowing the viewer to notice trends in the data at first glance, as opposed to the data being spread out making it difficult for the user to spot a trend.

Interaction:
In graph 4 I used an interactive feature known as tooltip. In my scatter plot I had decided to represent the years via the shade of green i.e. the lighter the colour the older the movie. However after implementing this graph I realised it would be difficult to differentiate the years purely based on colour as a lot of the data is stacked on top of each other therefore the colour of a specific piece of data could be misleading. In order to solve this issue and be able to interpret and analyse this graph a lot better, I decided to use an interactive feature so the user will be able to hover their mouse of the data and will be given the exact year of a particular piece of data. Having this feature is evidently better as, if we take a look at the two images below:

![image](./Images/interaction1.png)

We can see that the section marked in red can be interpreted as early or even late 2000s however after hovering my mouse over that section I found that, the section was highlighting and representing a movie in the mid 80s.
As opposed to the user being shown the information at face value, my graph allows them the the freedom to explore and navigate the data. In Shneiderman's article of "The Eyes Have it...' its mentioned that "exploration should be joyous". This quote made me realise that the user should be able to enjoy interpreting the data and should be given the enjoyment of coming up with conclusions for themselves. When studying this graph I remember feeling quote shocked there was not a direct correlation between votes and runtime, as a result I wanted the viewer to also feel contentment in coming up with these findings, therefore instead of making it explicit to the viewer I incorporated interaction for them to come up with this conclusion for themselves. Interacting with data can includes filtering as well as being able to 'explore' the dataset. In graph 6 I can included a map of countries that produced films. Here the user can hover their mouse over a particular region in order to be shown the country name and the number of movies developed by that country. As the code depicts ths information and provides it to the user, clarity and comprehensibility is enhanced as the user is not clustered with masses of information in order to spot a trend or pattern within the data. Additionally in graph 7 the budget and gross is displayed in an interactive manner. The user can slide across the the graph to analyse the data from different time frames. This is effective as the user can process the data carefully year by year as opposed to be shown a mass of data from different time frames and forced to come up with a conclusion. Additionally the user has freedom of flexibility to focus on certain pieces of data i.e. 1984 and 2013.

{|designJustification)}

{(references|}

- Cleveland, W. (1993) The Elements of Graphing Data, Hobart Press, ISBN 0963488411
- Stone, M. (2006) Choosing Colors for Data Visualization, Perceptual Edge.
- Wickham, H. (2014) Tidy Data, Journal of Statistical Software, 59(10).
- Muth, L-C. (2018) An alternative to pink & blue: Colors for gender data. Datawrapper blog
- McCandless, D. (2022) Information is Beautiful. IIB
- Kilin, I. (2022) The best charts for color blind viewers. Datylon
- Munzner, T. (2014). Visualization analysis and design. AK Peters/CRC Press.

{|references)}
