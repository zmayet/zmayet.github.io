---
id: litvis
---

@import "../lectures/css/datavis.less"

![Data visualization](../images/bannerNoLabel.jpg)

# IN3030 Data Visualization Portfolio

_Important: Please Add you name and City email address below and stage/commit/push to your Github repo._

## Name: (replace with you name here)

## City Email: (replace with your email here)

---

This is the place where you can place your weekly exercises and datavis project as you work on them during the term. You should regularly _stage_, _commit_ and _push_ your content here to GitHub to produce a continuous record of your work.
