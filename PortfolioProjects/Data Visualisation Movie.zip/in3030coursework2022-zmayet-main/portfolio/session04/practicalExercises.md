---
id: litvis

narrative-schemas:
  - ../../lectures/narrative-schemas/teaching.yml

elm:
  dependencies:
    gicentre/elm-vegalite: latest
    gicentre/tidy: latest
---

@import "../../lectures/css/datavis.less"

```elm {l=hidden}
import Tidy exposing (..)
import VegaLite exposing (..)
```

<!-- Everything above this line should probably be left untouched. -->

# Session 4: Practical Exercises

{(task|}

Use this document as a place to add your answers to the week's practical exercises.

{|task)}

## 6. Practical Exercises

{(task|} Please complete the following exercises before next week. {|task)}

### 1. Matching visual variables to data type and task property

Make sure you have completed the visual variable table tasks in the lecture notes above. If you are having trouble completing either of the tables, you may find [Roth (2017)](#5-recommended-reading) provides helpful guidance.

Discuss your choices with others in the lab class to see where you agree / disagree.

### 2. Graphical summary of channel properties

Consider the table of visual variables and the ratings you have given each of the 5 properties. In the example below, all ratings are 1, but when you have completed the question above, you should have values in the table between 1 and 3.

|     Visual variable | quantitative | orderable | selective | associative | dissociative |
| ------------------: | :----------: | :-------: | :-------: | :---------: | :----------: |
|        _colour hue_ |      1       |     1     |     1     |      1      |      1       |
| _colour saturation_ |      1       |     1     |     1     |      1      |      1       |
|  _colour lightness_ |      1       |     1     |     1     |      1      |      1       |
|       _orientation_ |      1       |     1     |     1     |      1      |      1       |
|             _shape_ |      1       |     1     |     1     |      1      |      1       |
|           _texture_ |      1       |     1     |     1     |      1      |      1       |
|       _arrangement_ |      1       |     1     |     1     |      1      |      1       |
|              _size_ |      1       |     1     |     1     |      1      |      1       |
|             _focus_ |      1       |     1     |     1     |      1      |      1       |
|          _location_ |      1       |     1     |     1     |      1      |      1       |

The following function will create a table of data that represents the table (again illustrated with ratings of 1 for all table cells).

```elm {l}
vvTable =
    let
        table =
            """visualVariable,    q, o, s, a, d
               colour hue,        1, 1, 1, 1, 1
               colour saturation, 2, 2, 3, 2, 2
               colour lightness,  3, 3, 3, 2, 2
               orientation,       1, 3, 3, 3, 3
               shape,             2, 2, 2, 3, 3
               texture,           3, 1, 3, 3, 1
               arrangement,       3, 1, 2, 3, 1
               size,              2, 2, 3, 3, 2
               focus,             2, 3, 3, 2, 3
               location,          3, 2, 2, 2, 3"""
                |> fromCSV
                |> gather "property"
                    "rating"
                    [ ( "q", "quantitative" )
                    , ( "o", "orderable" )
                    , ( "s", "selectable" )
                    , ( "a", "associative" )
                    , ( "d", "dissociative" )
                    ]
    in
    dataFromColumns []
        << dataColumn "visualVariable" (table |> strColumn "visualVariable" |> strs)
        << dataColumn "property" (table |> strColumn "property" |> strs)
        << dataColumn "rating" (table |> numColumn "rating" |> nums)
```

Update the '1's in this function to reflect your own ratings. Then see if you can produce a graphical summary of the table by encoding the ratings with one or more channels that you think provides a descriptive graphical summary.

You can use the following as a start point:

```elm {l v}
summary : Spec
summary =
    let
        enc =
            encoding
                << position Y [ pName "visualVariable" ]
                << position X [ pName "property" ]
                << shape [mName "rating"]
                << color [ mName "rating", mScale[scScheme "tableau10" []] ]
    in
    toVegaLite [ width 400, height 400, vvTable [], enc [], point [] ]
```

### 3. Design Challenge: Exploring data-channel design options

The [Gapminder](https://www.gapminder.org/data/) dataset at [vega.github.io/vega-lite/data/gapminder-health-income.csv](https://vega.github.io/vega-lite/data/gapminder-health-income.csv) shows the relationship between health, income and population numbers for the countries of the world.

| country             | income | health | population |
| ------------------- | ------ | ------ | ---------- |
| Afghanistan         | 1925   | 57.63  | 32526562   |
| Albania             | 10620  | 76     | 2896679    |
| Algeria             | 13434  | 76.5   | 39666519   |
| Andorra             | 46577  | 84.1   | 70473      |
| Angola              | 7615   | 61     | 25021974   |
| Antigua and Barbuda | 21049  | 75.2   | 91818      |
| Argentina           | 17344  | 76.2   | 43416755   |
| :                   | :      | :      | :          |

Create one or more litvis documents that explore some design possibilities for showing these data. In particular focus on exploring the use of different channels (e.g. position, colour, shape, size) to encode different data variables (country, income, health, population). You should come up with several different encodings and provide a brief evaluation of which ones work most effectively.

```elm {l v}
lifestyle : Spec
lifestyle =
    let
        data =
            dataFromUrl "https://vega.github.io/vega-lite/data/gapminder-health-income.csv"

        enc =
            encoding
                << position X
                    [ pName "income", pScale [ scType scLog ]]
                << position Y
                    [ pName "health", pQuant, pScale [ scZero False ]]
                << color [ mName "population", mScale [ scScheme "magma" [], scType scLog ] ]
    in
    toVegaLite [ width 400, height 400, data [], enc [], point [] ]
```

Some issues to consider:

- Are the best designs consistent with the guidance given for associating channels with data type (nominal, quant etc.) and task property (associative, orderable etc.)?
- Does double-encoding help or hinder interpretation?
- What are the advantages / disadvantages of encoding all variables in a single chart compared to separating them in multiple charts?
- Does perceptual (Flannery) scaling help in interpretation?
