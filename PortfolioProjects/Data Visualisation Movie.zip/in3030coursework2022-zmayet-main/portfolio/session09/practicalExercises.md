---
id: litvis

narrative-schemas:
  - ../../lectures/narrative-schemas/teaching.yml

elm:
  dependencies:
    gicentre/elm-vegalite: latest
    gicentre/tidy: latest
---

@import "../../lectures/css/datavis.less"

```elm {l=hidden}
import Tidy exposing (..)
import VegaLite exposing (..)
```

<!-- Everything above this line should probably be left untouched. -->

# Session 9: Practical Exercises

{(task|}

Use this document as a place to add your answers to the week's practical exercises.

{|task)}

## 7. Practical Exercises

{(task|} Please add answers to the following to your portfolio repo for session 9. This is the last of the continuous assessment exercises and is shorter than the others so you have time to devote to working on your datavis project, remembering to push regularly to the `project` folder of your repo. {|task)}

### 1. Comparison of Network Visualization Approaches

Considering the following techniques mentioned in the lecture, identify at least one advantage and disadvantage of each:

| Visualization Type             | Advantages                                                                                         | Disadvantages                                                                          |
| ------------------------------ | -------------------------------------------------------------------------------------------------- | -------------------------------------------------------------------------------------- |
| Node-link diagram              | _ the complexity is simplified thefore overview of the data / connections are clear _              | _do not scale well to larger more complex networks here_                               |
| Matrix view                    | _matrix views are much more scalable in that we use colour or point symbol_                        | _don't always take advantage of position to encode useful characteristics of the data_ |
| Sankey diagram                 | _show how a node is connected to several others_                                                   | _challenging to produce in Vega-Lite _                                                 |
| OD Map (grid map of grid maps) | _re-orders matrix cells hierarchically to preserve the spatial arrangement of grid cell locations_ | _Flows that start and end at the same location are not shown._                         |

### 2. Co-authorship Insights

Reviewing the various representations of the giCentre co-authorship visualizations, identify the three most useful insights you've gained. Briefly identify which visualization(s) led to the insight and how it did.

-Insight 1: (NodeLink2) This insight is in regards to the amount an author writes. The more they write the more likely they'll be a co author to a report. This differs from NodeLink1 as its much cleaner with better spacing.

-Insight 2: (SankeyCoAuthor) Authors 'co author' quite often compared to other. This is as four to five were part of a co authored report. Personal preference can be taken into account, however visually doesnt go into much detail.

-Insight 3: (CurvePlot) This insight made me realise how some authors prefer to co author with particular other authors. Some authors do not have a bias with who they co author with and are open to a range of other author, however some authors prefer to publish with specific few authors.

---
