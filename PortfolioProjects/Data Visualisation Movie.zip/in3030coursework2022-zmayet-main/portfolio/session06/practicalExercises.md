---
id: litvis

narrative-schemas:
  - ../../lectures/narrative-schemas/teaching.yml

elm:
  dependencies:
    gicentre/elm-vegalite: latest
    gicentre/tidy: latest
---

@import "../../lectures/css/datavis.less"

```elm {l=hidden}
import Tidy exposing (..)
import VegaLite exposing (..)
```

<!-- Everything above this line should probably be left untouched. -->

# Session 6: Practical Exercises

{(task|}

Consider this [interactive visualization example](https://www.staff.city.ac.uk/~jwo/pbp2015/). It shows the results of 6000 entrants in a bicycle race taking place over four days and 1250km from Paris to Brest and back. You can see the progress of individual riders by entering their IDs in the text box. Some examples to try include rider `A100`, rider `E103` and rider `F220`.

![Paris-Brest-Paris 2015](https://staff.city.ac.uk/~jwo/datavis2022b/session06/images/pbp2015.jpg)

How many of Shneiderman's 7 tasks are supported by the visualization? What role does interaction play in supporting them (if at all)? How would you improve the design to support the tasks more effectively?

For more details of the design approach used here, see [Wood, 2015](#references).

I believe 4 of Shneiderman's 7 have been used in this in this data visualisation. Having data you can interact with allows the user to retain more information as the information is interactive and fun to process. In order to improve this design I would add colours that don't blend in so much. Its better to use vivid colours so determine and distinguish patterns.

{|task)}

{(task|}Try adding `seNearest True` to the example above and observe the effect on interaction.{|task)}

The second problem can be addressed by _projecting_ the selection from just the single point to all data points that share some common characteristic. We can do this by specifying the fields (data variables) onto which the selection is to be projected. For example, to select all points with the same crime type as the selected point:

```elm {l highlight=[21-24,26-29]}
crimeColours =
    categoricalDomainMap
        [ ( "Anti-social behaviour", "rgb(59,118,175)" )
        , ( "Burglary", "rgb(81,157,62)" )
        , ( "Criminal damage and arson", "rgb(141,106,184)" )
        , ( "Drugs", "rgb(239,133,55)" )
        , ( "Robbery", "rgb(132,88,78)" )
        , ( "Vehicle crime", "rgb(213,126,190)" )
        ]
crimeData =
    dataFromUrl "https://gicentre.github.io/data/westMidlands/westMidsCrimesAggregated.tsv" []
```

```elm {l highlight=[21-24,26-29]}
encHighlight =
    encoding
        << position X [ pName "month", pTemporal, pAxis [ axTitle "", axGrid False ] ]
        << position Y [ pName "reportedCrimes", pQuant, pAxis [ axGrid False ] ]
        << color
            [ mCondition (prParamEmpty "mySelection")
                [ mName "crimeType", mScale crimeColours ]
                [ mStr "black" ]
            ]
        << opacity
            [ mCondition (prParamEmpty "mySelection")
                [ mNum 1 ]
                [ mNum 0.1 ]
            ]
```

```elm {l v interactive highlight=6}
domainProjection : Spec
domainProjection =
    let
        ps =
            params
                << param "mySelection" [ paSelect sePoint [ seNearest True, seFields [ "crimeType" ] ] ]

                  << param "mySelection" [ paSelect sePoint [seNearest True] ]
    in
    toVegaLite
        [ width 540
        , crimeData -- Data specified in separate code block
        , ps []
        , encHighlight [] -- Encoding specified in separate code block
        , circle []
        ]
```

{(task|}Test this interaction specification works by dragging over a range in the chart. In what circumstances might this form of selection be useful?
This helps to section out a small set of data thus the user would be able to process the data more efficiently as other pieces of information would not be visible to the user hence avoiding confusion.
{|task)}

{(task|}Test this interaction specification works by moving the mouse pointer over points with the shift-key held down. In what circumstances might this form of selection be useful and an advantage over a rectangular interval selection?
This would give the viewer freedom to pin point certain / particular poins on the graph which is useful as the user would now be able to make a clearer comparison between certain points and notice a trend or pattern.
{|task)}

#### 2.1 Direct Interaction

| Advantages                                     | Disadvantages                                                         |
| :--------------------------------------------- | :-------------------------------------------------------------------- |
| Zooming and panning more intuitive             | Difficult to select densely positioned marks                          |
| Value / data can be viewed to be more accurate | Not user friendly                                                     |
| Trends can be spotted quicker                  | The user can struggle to pin point a specific sector within the graph |

#### 2.2 Indirect Interaction

| Advantages                                               | Disadvantages                                                                                                                                 |
| :------------------------------------------------------- | :-------------------------------------------------------------------------------------------------------------------------------------------- |
| Can select non position-encoded data ranges              | An option can be selected accidenly as the process to clicking is smooth and efficient resulting in an option being selected unintentionally. |
| Brings the user a satisfactory feeling.                  | Requires excessive space                                                                                                                      |
| User friendly, not complicated to understand the concept | A variety of options can be misleading.                                                                                                       |
