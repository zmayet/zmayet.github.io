---
id: litvis

narrative-schemas:
  - ../../lectures/narrative-schemas/teaching.yml

elm:
  dependencies:
    gicentre/elm-vegalite: latest
    gicentre/tidy: latest
---

@import "../../lectures/css/datavis.less"

```elm {l=hidden}
import Tidy exposing (..)
import VegaLite exposing (..)
```

<!-- Everything above this line should probably be left untouched. -->

# Session 5: Practical Exercises

{(task|}

```elm {l=hidden}
newTable : Table
newTable =
    """Rank,Country,G,S,B
        1,China,96,60,51
2,GB,41,38,45
3,US,37,36,31
4,RPC,36,33,49 """
        |> fromCSV
        |> gather  "G/S/B"  "Medals"[ ( "G", "Gold" ), ( "S", "Silver" ), ( "B", "Bronze" ) ]
```

^^^elm {m=(tableSummary -1 newTable)}^^^

{|task)}
