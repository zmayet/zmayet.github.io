---
id: litvis

narrative-schemas:
  - ../../lectures/narrative-schemas/teaching.yml

elm:
  dependencies:
    gicentre/elm-vegalite: latest
    gicentre/tidy: latest
---

@import "../../lectures/css/datavis.less"

```elm {l=hidden}
import Tidy exposing (..)
import VegaLite exposing (..)
```

<!-- Everything above this line should probably be left untouched. -->

# Session 3: Practical Exercises

{(task|}

{(task|} Explore the baby name voyager and see if you can find any interesting patterns. In what ways has colour been used to make finding these patterns easier? Would you use colour in any different ways if you were to create a similar baby-name explorer? {|task)}

{(annotation|} I personally think the use of colour is extremely helpful, as it helps process the data provided in the graph. This particular diagram uses colours such as blue, pink, red etc. The colour helps
 {|annotation)}

 Which measurement types (e.g. `Nominal`, `Ordinal`, `Quant`, `Temporal`) and which [colour schemes](https://vega.github.io/vega/docs/schemes/) (e.g. `category20`, `purples` etc.) would you specify for the following data. Briefly add your reasoning to the table below and then copy it to your exercises document in your coursework portfolio repo:

| Data                                                                                           | Measurement type | Colour Scheme      | Justification                                                                                                                                                                                                                        |
| ---------------------------------------------------------------------------------------------- | ---------------- | ------------------ | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ |
| 1. Student cohorts in an attendance streamgraph                                                | Ordinal          | Purple, Blue         | I would choose to use these colours as the piece od data is in regards to a group of students. The students that define themselves as girls can be purple whilst the students that define themselves as male can be blue.              |
| 2. FTSE 100 indices over the last 12 months                                                    | Temporal         | # blues            | When data related to stocks are shown there isn't a particular colour needed to represent the data or to make it clearer to read. Hence picking a generic blue colour will be suffice.                                               |
| 3. Your assessment marks for all completed modules                                             | Quant            | Green, Yellow, Red | When these colours are linked with grades / score the general rule that is implied is green means on track and red is off track. As these colours are used to judge assessment scores sticking to these colours would be wise.       |
| 4. Political party of elected MPs                                                              | Ordinal          | Blue, Red, Green   | These colours were chosen by these parties therefore having them represent the data would clearly indicate what party / MP is being talked about.                                                                                    |
| 5. Responses to a 5-point [Likert](https://en.wikipedia.org/wiki/Likert_scale) survey question | Nominal          | Gold               | These scales are generally used for individuals to give a score regarding their personal options in regards to certain topic thus the higher the rating the more gold would be seen which would visually look like a positive score. |

{|task)}


```elm {v l}
attendance : Spec
attendance =
    let
        cfg =
            configure
                << configuration (coView [ vicoStroke Nothing ])
                << configuration (coAxis [ axcoTicks False, axcoDomain False, axcoLabelAngle 0 ])

        data =
            dataFromUrl "https://gicentre.github.io/data/attendance.csv"
                -- Force session values to be treated as numbers not text
                [ parse [ ( "session", foNum ) ] ]

        enc =
            encoding
                << position X [ pName "session" ]
                << position Y
                    [ pName "attendance"
                    , pQuant
                    , pStack stCenter -- Stacked from the centre not bottom.
                    , pAxis []
                    ]
                << detail [ dName "id" ]
                << color [ mName "cohort", mScale [scScheme "bluepurple" []] ] 
    in
    toVegaLite
        [ width 600
        , height 300
        , cfg []
        , data
        , enc []
        , area
            [ maLine (lmMarker []) -- Add lines around each area 'stream'
            , maInterpolate miMonotone -- Monotone interpolation gives curved lines
            ]
        ]
```
The colour scheme I have chose does not work with this particular graph. Magority of the graph is blue which doesn't really tell the viewer much information, therefore the use of this colour is uneccessary.
{|task)}
