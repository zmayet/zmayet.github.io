---
follows: imdbRoot
---

A default histogram:

```elm {l v}

histogram : Spec
histogram =
    let
         cfg =
            configure
                << configuration (coView [ vicoStroke Nothing ])
                << configuration (coAxis [ axcoTicks False, axcoDomain False ])
         enc =
            encoding
                << position X [ pName "IMDB Rating", pBin [], pAxis [ axTitle "", axValues (nums [ 1, 10 ]) ] ]
                << position Y [ pAggregate opCount , pAxis [ axTitle "", axValues (nums [ 0, 500, 1000  ]) ]]
               -- << color [, mName "IMDB Rating", mOrdinal ]
                
    in
    toVegaLite [cfg [], data, enc [], bar [] ]
```
